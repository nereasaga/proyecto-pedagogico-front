<template>
  <nav class="navbar">
    <div class="navbar-container">
      <div class="logo">MiLogo</div>
      <div class="nav-actions" :class="{ open: isMenuOpen }">
        <template v-if="user">
          <span class="user-email">{{ user.email }}</span>
          <button @click="logout">Salir</button>
        </template>
        <template v-else>
          <button @click="goToLogin">Entrar</button>
          <button @click="register">Registrarse</button>
        </template>
      </div>
      <button class="menu-toggle" @click="isMenuOpen = !isMenuOpen">
        ☰
      </button>
    </div>
  </nav>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { useAuthStore } from '../stores/auth'
import { computed, ref } from 'vue'

const router = useRouter()
const auth = useAuthStore()
const user = computed(() => auth.user)

const isMenuOpen = ref(false)

const logout = () => {
  auth.logout()
  isMenuOpen.value = false
}

const goToLogin = () => {
  router.push('/')
  isMenuOpen.value = false
}

const register = () => {
  alert('Registro aún no implementado.')
  isMenuOpen.value = false
}
</script>

<style scoped>
.navbar {
  width: 100%;
  background-color: #f9f9f9;
  border-bottom: 1px solid #ddd;
  padding: 0.5rem 0;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
}

.navbar-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 1rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: relative;
}

.logo {
  font-weight: bold;
  font-size: 1.5rem;
  color: #333;
}

.nav-actions {
  display: flex;
  gap: 1rem;
  align-items: center;
}

.nav-actions button {
  background: transparent;
  border: 1px solid #333;
  padding: 0.4rem 0.8rem;
  border-radius: 4px;
  cursor: pointer;
  color: #333;
  transition: all 0.2s ease;
}

.nav-actions button:hover {
  background-color: #eaeaea;
}

.user-email {
  font-size: 0.9rem;
  color: #555;
}

.menu-toggle {
  display: none;
  font-size: 1.5rem;
  background: none;
  border: none;
  cursor: pointer;
  color: #333;
}

@media (max-width: 768px) {
  .nav-actions {
    position: absolute;
    top: 100%;
    right: 0;
    background: #fff;
    border-left: 1px solid #ccc;
    border-bottom: 1px solid #ccc;
    flex-direction: column;
    width: 200px;
    display: none;
    padding: 1rem;
    z-index: 10;
  }

  .nav-actions.open {
    display: flex;
  }

  .menu-toggle {
    display: block;
  }
}
</style>
