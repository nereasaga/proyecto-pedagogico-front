<template>
  <div class="panel">
    <h2>Panel del Usuario</h2>
    <p><strong>Nombre:</strong> {{ user?.name }}</p>
    <p><strong>Email:</strong> {{ user?.email }}</p>
    <button @click="logout">Cerrar sesión</button>
  </div>
</template>

<script setup>
import { useAuthStore } from '../stores/auth'
import { onMounted } from 'vue'
import { useRouter } from 'vue-router'

const auth = useAuthStore()
const router = useRouter()
const user = auth.user

onMounted(() => {
  if (!user) router.push('/')
})

const logout = () => {
  auth.logout()
}
</script>

<style scoped>
.panel {
  max-width: 500px;
  margin: 4rem auto;
}
button {
  margin-top: 1rem;
}
</style>
